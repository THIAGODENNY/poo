package semana07;

public class Ferrari implements Motor, Capota {

	@Override
	public void open() {
		// TODO Auto-generated method stub

	}

	@Override
	public void close() {
		// TODO Auto-generated method stub

	}

	@Override
	public void acionar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void ligar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void desligar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void acelerar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void frear() {
		// TODO Auto-generated method stub

	}

}
