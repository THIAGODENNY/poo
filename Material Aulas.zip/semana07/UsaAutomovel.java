package semana07;

public class UsaAutomovel {

	public static void main(String[] args) {

		Automovel a = new Automovel();
		//Motor m = new Motor();

	}

}
