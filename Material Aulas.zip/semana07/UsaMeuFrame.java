package semana07;

public class UsaMeuFrame {

	public static void main(String[] args) {
		MeuFrame f = new MeuFrame();
		f.lb.setText("Ola");
		f.bt.setText("Calcular");
		f.tf.setText("Teste");

	}

}
