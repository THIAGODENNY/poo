package semana07;

public abstract class Animal {

	public abstract void comer();
	public abstract void beber();
	public abstract void andar();
	public abstract void correr();
	
	public void mostrar() {
		System.out.println("Oi");
	}
	
}
