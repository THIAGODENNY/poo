package semana07;

public class Automovel implements Motor{
	
	public void desligar() {
		System.out.println("Desligando");
	}
	public void acelerar() {
		System.out.println("Acelerando");
	}
	public void frear() {
		System.out.println("Freando");
	}
	@Override
	public void ligar() {
		System.out.println("Ligando");
	}

}
