package semana07;

public class Funcionario {
	public String nome;
	public double salario;
	public static String empresa;
	
	public void mostrar() {
		System.out.println(nome);
		System.out.println(salario);
		System.out.println(empresa);
	}
	public static void verEmpresa() { 
		System.out.println(empresa);
	}
}
