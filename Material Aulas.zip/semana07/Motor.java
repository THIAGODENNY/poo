package semana07;

public interface Motor {
//contem apenas especifica��es do m�todo
	public void ligar();
	public void desligar();
	public void acelerar();
	public void frear();
	
}
