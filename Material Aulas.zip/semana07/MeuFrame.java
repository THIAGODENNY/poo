package semana07;

import javax.swing.JLabel;

public class MeuFrame implements 
             Interface01,Interface02{
	
	public JLabel lb = new JLabel();

}
