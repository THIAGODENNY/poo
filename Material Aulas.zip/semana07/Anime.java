package semana07;

public class Anime implements Fisio {

	@Override
	public void dormir() {
		System.out.println("Animal dormindo");
	}

	@Override
	public void comer() {
		System.out.println("Animal comendo");
	}

	@Override
	public void beber() {
		System.out.println("Animal bebendo");
	}

	@Override
	public void andar() {
		System.out.println("Animal andando");
	}

}
