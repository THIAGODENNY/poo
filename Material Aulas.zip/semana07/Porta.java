package semana07;

public interface Porta {
	void open();
	public void close();
}
