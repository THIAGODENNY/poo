package semana07;

public interface Fisio {
	
	public void dormir();
	public void comer();
	public void beber();
	public void andar();
	
}
