package semana07;

import javax.swing.JTextField;

public interface Interface01 {
	JTextField tf = new JTextField();
}
