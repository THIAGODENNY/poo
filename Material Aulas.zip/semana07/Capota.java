package semana07;

public interface Capota extends Porta {

	public void acionar();
}
