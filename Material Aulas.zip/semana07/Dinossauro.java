package semana07;

public class Dinossauro extends Animal {

	@Override
	public void comer() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void beber() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void andar() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void correr() {
		// TODO Auto-generated method stub
		
	}

	
}
