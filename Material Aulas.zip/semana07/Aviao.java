package semana07;

public class Aviao implements Motor {

	@Override
	public void ligar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void desligar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void acelerar() {
		// TODO Auto-generated method stub

	}

	@Override
	public void frear() {
		// TODO Auto-generated method stub

	}

}
