package semana07;

public class UsaFuncionario {

	public static void main(String[] args) {

		Funcionario f = new Funcionario();
		f.nome = "Jo�o";
		f.salario = 10000;
		f.empresa = "XYZ"; //errado
		f.mostrar();

		Funcionario.empresa = "FATEC";
		Funcionario.verEmpresa();
		
		
	}

}
