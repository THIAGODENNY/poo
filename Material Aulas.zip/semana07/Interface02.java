package semana07;

import javax.swing.JButton;

public interface Interface02 {
	JButton bt = new JButton("Calcular");
}
