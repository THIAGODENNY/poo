package model;
import java.sql.SQLException;

import services.BD;
public class ProdutoDAO implements DAO{

	public Produto produto = new Produto();
	public BD bd = new BD();
	private String sql, ret; //vari�veis internas
	/**
	 * Grava ou altera um produto
	 * @param p - o produto a ser salvo
	 * @return - mensagem de retorno
	 */
	public String salvar(Produto p) {
		sql = "insert into produtos values (?,?,?,?)";
		try {
			bd.getConnection();
			bd.st = bd.con.prepareStatement(sql);
			bd.st.setInt(1, p.getCodigo());
			bd.st.setString(2, p.getNome());
			bd.st.setDouble(3, p.getPreco());
			bd.st.setInt(4, p.getEstoque());
			bd.st.executeUpdate();
			ret = "Sucesso na inclus�o";
		}
		catch(SQLException erro) {
			
			sql = "update produtos set nome=?, "
				+ "preco=?,estoque=? where codigo=?";
			try {
				bd.st = bd.con.prepareStatement(sql);
				bd.st.setInt(4, p.getCodigo());
				bd.st.setString(1, p.getNome());
				bd.st.setDouble(2, p.getPreco());
				bd.st.setInt(3, p.getEstoque());
				bd.st.executeUpdate();
				ret = "Sucesso na altera��o";
			}
			catch(SQLException e) {
				ret = "Falha "+e.toString();
			}
		}
		finally {
			bd.close();
		}
		return ret;
	}
	@Override
	public String excluir(int codigo) {
		sql = "delete from produtos where codigo=?";
		try {
			bd.getConnection();
			bd.st = bd.con.prepareStatement(sql);
			bd.st.setInt(1, codigo);
			int n = bd.st.executeUpdate();
			if(n==1) { ret="Exclus�o realizada";}
			else {ret="C�digo n�o localizado";}
		}
		catch(SQLException erro) {
			ret = "Falha "+erro.toString();
		}
		finally { bd.close(); }
		return ret;
	}
	
	public Produto localizar(int codigo) {
		sql = "select * from produtos where "
				+ "codigo = ?";
		try {
			bd.getConnection();
			bd.st = bd.con.prepareStatement(sql);
			bd.st.setInt(1,codigo);
			bd.rs = bd.st.executeQuery();
			if(bd.rs.next()) { //copia bd-->objeto
				produto.setCodigo(bd.rs.getInt(1));
				produto.setNome(bd.rs.getString(2));
				produto.setPreco(bd.rs.getDouble(3));
				produto.setEstoque(bd.rs.getInt(4));
				return produto;
			}
			else {
				return null;
			}
		}
		catch(SQLException erro) {
			return null;
		}
		finally {
			bd.close();
		}
		
	}
	public String popular() {
		sql = "insert into produtos values (?,?,?,?)";
		try {
			bd.getConnection();
			bd.st = bd.con.prepareStatement(sql);
			for(int a=1;a<=1000;a++) {
				bd.st.setInt(1,a);
				bd.st.setString(2,"Produto "+a);
				bd.st.setDouble(3, a*0.32);
				bd.st.setInt(4, 100 );
				bd.st.executeUpdate();
			}	
			ret = "1000 linhas geradas";
		}
		catch(SQLException erro) {
			ret = "falha "+erro.toString();
		}
		finally {
			bd.close();
		}
		return ret;
	}
	
	@Override
	public void listar() {
		sql="select * from produtos";
		try {
			bd.getConnection();
			bd.st = bd.con.prepareStatement(sql);
			bd.rs = bd.st.executeQuery();
			while(bd.rs.next()) {
				System.out.println("["+
			          bd.rs.getInt(1)+","+
			          bd.rs.getString(2)+","+
			          bd.rs.getFloat(3)+","+
			          bd.rs.getInt(4)+"]");
			}
		}
		catch(SQLException erro) {
			System.out.println(erro.toString());
		}
		finally { bd.close();}
		
	}
}
