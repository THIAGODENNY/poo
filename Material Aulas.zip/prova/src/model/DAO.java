package model;

public interface DAO {
	public String excluir(int codigo);
	public void listar();
}
