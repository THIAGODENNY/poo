package test;

import javax.swing.JOptionPane;

import model.Produto;
import model.ProdutoDAO;

public class ProdutoLocalizar {
	public static void main(String[] args) {
		
		ProdutoDAO dao = new ProdutoDAO();
		//System.out.println(dao.popular());
		int cod = Integer.parseInt(
		   JOptionPane.showInputDialog("C�digo?"));
		Produto p = dao.localizar(cod);
		if(p!=null) {
			p.mostrar();
		}
		//dao.listar();
	}
}
