package test;

import model.Produto;
import model.ProdutoDAO;

public class ProdutoSalvar {
	public static void main(String[] args) {
		Produto p = 
			new Produto(1,"Sabonete",1.34,200);
		ProdutoDAO dao = new ProdutoDAO();
		System.out.println(dao.salvar(p));
	}
}
