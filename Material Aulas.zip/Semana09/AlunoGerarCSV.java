package semana09;

import java.sql.SQLException;

import semana08.BD;

public class AlunoGerarCSV {

	public static void main(String[] args) {
		Texto texto = new Texto();
		BD bd = new BD();
		bd.getConnection();
		String sql = "select * from aluno";
		String linha = "";
		try {
			bd.st = bd.con.prepareStatement(sql);
			bd.rs = bd.st.executeQuery();
			while(bd.rs.next()) {
				linha += bd.rs.getString(1) + ";"+
						 bd.rs.getString(2) + ",";
			}
		}
		catch(SQLException erro) {
			System.out.println(erro.toString());
		}
		finally {
			bd.close();
		}
		String[] vetor = linha.split(",");
		System.out.println(
			texto.gravar("src/semana09/",
			"alunos.csv", vetor));
	}

}
