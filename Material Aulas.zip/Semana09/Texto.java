package semana09;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class Texto {
	/**
	 * Grava um arquivo texto no caminho indicado pelo usu�rio
	 * @param caminho - o caminho onde o arquivo ser� criado
	 * @param nomeDoArquivo - o nome do arquivo que ser� criado
	 * @param linhas - o conte�do a ser gravado no arquivo (cada elemento do array cont�m uma linha a ser gravada)
	 * @return - Uma mensagem informnado o sucesso ou n�o da opera��o
	 */
	public String gravar(String caminho, String nomeDoArquivo, String[] linhas){
		try{
			PrintWriter pw = new PrintWriter(caminho+nomeDoArquivo); //cria arquivo no caminho especificado
			for(int i=0; i<linhas.length; i++) {
				pw.println(linhas[i]);
			}
			pw.flush(); //grava
			pw.close(); //fecha
			return "Arquivo gravado com sucesso!";
		}
		catch(IOException erro){
			return "Falha ao gravar o arquivo: "+erro.toString();
		}
	}

	/**
	 * Realiza a leitura de um arquivo texto a partir do caminho e nome do arquivo
	 * @param caminho - o caminho onde o arquivo est� localizado
	 * @param nomeDoArquivo - o nome do arquivo a ser lido
	 * @param quantLinhas - a quantidade de linhas a ler do arquivo (a partir da primeira linha do arquivo)
	 * @return - um array do tipo String contendo todas as linhas lidas
	 */
	public String[] ler(String caminho, String nomeDoArquivo, int quantLinhas){ 
		try{
			BufferedReader br = new BufferedReader(new FileReader(caminho+nomeDoArquivo)); //abre o arquivo texto
			String[] linhas = new String[quantLinhas]; //cria um vetor com a quantidade de linhas do arquivo texto
			for(int i=0; i<quantLinhas; i++) {
				linhas[i] = br.readLine(); //transfere todas as linhas ao vetor
		//		System.out.println(linhas[i]);
			}
			
			br.close();
			return linhas;
		}
		catch(IOException erro){
			return null;
		}
	}
	

}
