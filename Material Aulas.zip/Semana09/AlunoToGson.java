package semana09;

import com.google.gson.Gson;

public class AlunoToGson {
	public static void main(String[] args) {
		Aluno a = new Aluno();
		a.ra = "123";
		a.nome="Camila dos Santos";
		Gson g = new Gson();
		String json = g.toJson(a);
		System.out.println(json);
	}
}
