package semana09;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;

import semana08.BD;

public class AlunoImportarCSV {
	public static void main(String[] args) {
		String file = 
			"src/semana09/alunos_poo.csv";
		String linha="";
		
		String separador=";";
		BD bd = new BD();
		bd.getConnection();
		//abrir arquivo texto
		try {
		BufferedReader br =
			new BufferedReader(
				new FileReader(file));
		
		br.readLine(); //pular linha
		String sql = "insert into aluno values(?,?)";
		try {
			bd.st = bd.con.prepareStatement(sql);
		}
		catch(SQLException e) {	}
		
		while((linha=br.readLine())!=null){
			String[] aluno = linha.split(separador);
			try {
				bd.st.setString(1, aluno[0].trim());
				bd.st.setString(2, aluno[1].trim());
				bd.st.executeUpdate();
				System.out.println("[ra="+aluno[0].trim()+
						", nome="+aluno[1].trim());
			}
			catch(SQLException e) {
				System.out.println(e.toString());
			}

		}
		}
		catch(IOException erro) {
		}
		finally {
			bd.close();
		}
		
	}

}
