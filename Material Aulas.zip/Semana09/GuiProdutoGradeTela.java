package banco02;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;


public class GuiProdutoGradeTela extends JPanel {
	private JButton btNovo;
	private JButton btSalvar;
	private JButton btBuscar;
	private JLabel lbCodigo;
	private JLabel lbNome;
	private JLabel lbPreco;
	private JLabel lbEstoque;
	private JButton btExcluir;
	private JTextField tfCodigo;
	private JTextField tfNome;
	private JTextField tfPreco;
	private JTextField tfEstoque;
	private ProdutoDao pdao; 
	private Produto p;

	private JTextField tfLocalizar;
	private JTable table;
	private DefaultTableModel model;
	private BD bd;


	public GuiProdutoGradeTela() {
		pdao  = new ProdutoDao(); 
		p  = new Produto(); 
		bd = new BD();
		bd.getConnection();

		inicializarComponentes();
		definirEventos();
	}

	public void inicializarComponentes() {
		btNovo = new JButton ("Novo");
		btSalvar = new JButton ("Salvar");
		btBuscar = new JButton ("Buscar");
		lbCodigo = new JLabel ("Codigo");
		lbNome = new JLabel ("Nome");
		lbPreco = new JLabel ("Preco Unitario");
		lbEstoque = new JLabel ("Estoque");
		btExcluir = new JButton ("Excluir");
		tfCodigo = new JTextField (5);
		tfNome = new JTextField (5);
		tfPreco = new JTextField (5);
		tfEstoque = new JTextField (5);
		tfLocalizar = new JTextField(10);
		table = new JTable();

		setPreferredSize (new Dimension (600, 430));
		setLayout (null);

		add (btNovo);
		add (btSalvar);
		add (btBuscar);
		add (lbCodigo);
		add (lbNome);
		add (lbPreco);
		add (lbEstoque);
		add (btExcluir);
		add (tfCodigo);
		add (tfNome);
		add (tfPreco);
		add (tfEstoque);
		add(tfLocalizar);

		btNovo.setBounds (5, 150, 75, 20);
		btSalvar.setBounds (85, 150, 80, 20);
		btBuscar.setBounds (105, 15, 75, 25);
		btExcluir.setBounds (170, 150, 90, 20);

		lbCodigo.setBounds (5, 15, 45, 25);
		lbNome.setBounds (5, 45, 45, 25);
		lbPreco.setBounds (5, 75, 90, 25);
		lbEstoque.setBounds (5, 105, 55, 25);
		tfCodigo.setBounds (55, 15, 45, 25);
		tfNome.setBounds (55, 45, 280, 25);
		tfPreco.setBounds (95, 75, 70, 25);
		tfEstoque.setBounds (60, 105, 35, 25);

	}

	public void definirEventos() {

	}

	public static void main (String[] args) {
		JFrame frame = new JFrame ("GuiProduto");
		frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().add (new GuiProdutoGradeTela());
		frame.pack();
		frame.setVisible (true);
	}
}
