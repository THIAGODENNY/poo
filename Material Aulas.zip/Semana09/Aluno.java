package semana09;
public class Aluno {
	public String ra, nome;
}
