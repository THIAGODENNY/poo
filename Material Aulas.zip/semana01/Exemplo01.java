package semana01;

public class Exemplo01 {

}
