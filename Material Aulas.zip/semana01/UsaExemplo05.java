package semana01;

public class UsaExemplo05 {

	public static void main(String[] args) {
		String[] v1 = {"10","5","+"};
		Exemplo05.main(v1);
		
		String[] v2 = {"10","5","-"};
		Exemplo05.main(v2);

		String[] v3 = {"10","5","*"};
		Exemplo05.main(v3);

		String[] v4 = {"10","6","/"};
		Exemplo05.main(v4);


	}

}
