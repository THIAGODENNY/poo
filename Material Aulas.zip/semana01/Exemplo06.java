package semana01;

import javax.swing.JOptionPane;

public class Exemplo06 {

	public static void main(String[] args) {
		String s = JOptionPane.showInputDialog("nome");
		if(s!=null) {
			JOptionPane.showMessageDialog(null, s);
		}
		else {
			JOptionPane.showMessageDialog(null, "Cancel Pressionado");
		}
	}

}
