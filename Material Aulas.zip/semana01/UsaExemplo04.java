package semana01;

public class UsaExemplo04 {

	public static void main(String[] args) {
		String[] v = {"10","20","30"};
		Exemplo04.main(v);
	}

}
