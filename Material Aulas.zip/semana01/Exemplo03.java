package semana01;

/*
 * Essa classe demonstra alguns tipos de dado
 * Multiplas linhas
 */
public class Exemplo03 {
	
	//esse � o m�todo main
	public static void main(String[] args) {
 
		int idade = 3;
		float notaProva = 7.5f;
		double totalDaCompra = 1240.56;
		char d = 'm';
		boolean e = true;
		long f;
		
		Double g = 6.76;
		Float h = 5.3f;
		String i = "Aula de Java";
		
	}
}
