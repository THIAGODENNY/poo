package semana01;

public class Exemplo04 {
	public static void main(String[] args) {
		System.out.println(args.length); //2
		System.out.println(args[0]); //"10"
		System.out.println(args[1]); //"20"
	}
}
