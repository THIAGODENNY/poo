package semana05;
public class Pessoa {
	protected int codigo;
	public String nome;
	public void mostrar() {
		System.out.println(codigo);
		System.out.println(nome);
	}
}
