package semana05;

public class Mamifero extends Animal {
 
	public int tempoAmamentacao;
	 
}
 
