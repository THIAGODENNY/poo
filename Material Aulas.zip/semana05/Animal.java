package semana05;
public abstract class Animal {
	public int codigo;
	public int nomeCientifico;
}
 
