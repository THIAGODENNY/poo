package semana05;

public class UsaFuncionario {
	
	public static void main(String[] args) {
		Funcionario f = new Funcionario();
		f.codigo = 1;
		f.nome = "Paulo";
		f.rg = "123";
		f.cpf = "456";
		f.salario = 1000;
		f.mostrar();
	}

}
