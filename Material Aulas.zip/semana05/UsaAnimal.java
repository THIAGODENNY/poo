package semana05;

public class UsaAnimal {
	public static void main(String[] args) {
		//Animal a = new Animal();
		Ave ave = new Ave();
		Mamifero m = new Mamifero();

	}

}
