package semana05;

public class Ave extends Animal {
 
	public String formaAsa;
	 
}
 
