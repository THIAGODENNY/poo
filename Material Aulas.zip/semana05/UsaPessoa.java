package semana05;

public class UsaPessoa {

	public static void main(String[] args) {
		Pessoa p = new Pessoa();
		
		System.out.println(p.getClass());
		System.out.println(p.hashCode());
		System.out.println(p.toString());

	}

}
