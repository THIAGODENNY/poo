package semana02;

public class Exemplo07 {

	public static void main(String[] args) {
		int a;
		for(a=0; a<=10; a++) {
			System.out.print(a+" ");
		}
		System.out.println("\n-----------------------");

		
		for(a=10; a>=0; a--) {
			System.out.print(a+" ");
		}
		
		System.out.println("\n-----------------------");
	
		for(char b='A'; b<='z'; b++) {
			System.out.print(b+" ");
		}
	
	}

}
