package semana02;

import javax.swing.JOptionPane;

public class Exemplo05 {

	public static void main(String[] args) {
		String a = JOptionPane.showInputDialog("Numero?");
		if(a.equals("1")) {
			System.out.println("Um");
		}
		else if(a.equals("2")) {
			System.out.println("Dois");
		}
		//...
		else if(a.equals("9")) {
			System.out.println("Nove");
		}
		else {
			System.out.println("Desconhecido!");
		}

	}

}
