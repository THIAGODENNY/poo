package semana04;

public class AppPincel {

	public static void main(String[] args) {
		Pincel pincel01;
		
		Pincel pincel03 = new Pincel();
		pincel03.imprimirEstado();
/*		
		pincel01 = new Pincel();
		pincel01.cor = "Azul";
		pincel01.fabricante="FAber Castell";
		pincel01.preco = 4.56;
				
		Pincel pincel02 = new Pincel();
		pincel02.cor = "Verde";
		pincel02.fabricante="Pilot";
		pincel02.preco = 3.43;
		
		pincel01.imprimirEstado();
		String x = pincel02.toString();
		System.out.println(x);
*/		
		
		
	}

}
