package semana06;

public class UsaInterruptorFlex {

	public static void main(String[] args) {
		Lampada l1 = new Lampada();
		Lampada l2 = new Lampada();
		
		
		
		InterruptorFlex i = new InterruptorFlex();
		i.acionar(l1);
		l1.mostrar();
		i.acionar(l2);
		l2.mostrar();
	}

}
