package semana06;
public class Livro {
	public String isbn, titulo;
	public int qtdePaginas;
	public void mostrar() {
		System.out.println(isbn);
		System.out.println(titulo);
		System.out.println(qtdePaginas);
	}
}
