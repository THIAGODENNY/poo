package semana06;

public class Descascador {

	public static void main(String[] args) {
		
/*		Banana b = new Banana();
		b.descascar();
		Laranja l = new Laranja();
		l.descascar();
		Abacaxi a = new Abacaxi();
		a.descascar();
		*/
		
		Fruta f = new Banana();
		f.descascar();
		
		
	}

}
