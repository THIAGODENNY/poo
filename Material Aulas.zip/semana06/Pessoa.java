package semana06;

public class Pessoa {

	public int codigo;
	public String nome;
	public Pessoa conjuge;
	
	public void mostrar() {
		System.out.println(codigo);
		System.out.println(nome);
		if(conjuge!=null) {
			System.out.println("Conjuge: "+
		                     conjuge.nome);
		}
	}
}
