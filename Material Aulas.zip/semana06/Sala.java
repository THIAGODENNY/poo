package semana06;

public class Sala extends Comodo{

	public Ar ar = new Ar();
	public Lampada lampada2 = new Lampada();
}
