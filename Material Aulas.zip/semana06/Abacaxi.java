package semana06;

public class Abacaxi extends Fruta{
	public int tamanhoCoroa;
	
	public void descascar() {
		System.out.println("Descascando o abacaxi");
	}
}
