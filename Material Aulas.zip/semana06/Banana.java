package semana06;

public class Banana extends Fruta {

	public String tipo;

	public void descascar() {
		System.out.println("Descascando a banana!");
	}
}
