package semana06;
public class Item {
	public int numero;
	public String produto;
	public int quantidade;
}
