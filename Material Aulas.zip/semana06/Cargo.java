package semana06;

public class Cargo {
	public int codigo;
	public String nome;
	public double salarioMedio;
	
	public void mostrar() {
		System.out.println(codigo);
		System.out.println(nome);
		System.out.println(salarioMedio);
	}
}
