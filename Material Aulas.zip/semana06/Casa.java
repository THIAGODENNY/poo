package semana06;

public class Casa {

	public Quarto q1 = new Quarto();
	public Quarto q2 = new Quarto();
	public Quarto q3 = new Quarto();
	public Sala sala = new Sala();
	
}
