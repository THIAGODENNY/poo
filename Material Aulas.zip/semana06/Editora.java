package semana06;
public class Editora {
	public String nome;
	public Livro[] livros;
	
	public void mostrarTodosLivros() {
		for(int a=0; a<livros.length; a++) {
			livros[a].mostrar();
		}
		
	}
	
}
