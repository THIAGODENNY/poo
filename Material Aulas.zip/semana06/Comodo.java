package semana06;

public abstract class Comodo {

	public float largura, comprimento;
	public Lampada lampada = new Lampada();
	
	
}
