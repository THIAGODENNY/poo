package semana06;

public abstract class Fruta {
	public double preco;
	
	public void descascar() {
		System.out.println("Descascando a fruta!");
	}
}
