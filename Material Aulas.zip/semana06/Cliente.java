package semana06;
public class Cliente {
	public int codigo;
	public String nome;
}
