package semana06;

public class Quarto extends Comodo{
	public Ar ar = new Ar();
}
