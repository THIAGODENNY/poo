package semana06;

public class Laranja extends Fruta{
	public boolean exportacao;
	
	public void descascar() {
		System.out.println("Descascando a Laranja");
	}
}
