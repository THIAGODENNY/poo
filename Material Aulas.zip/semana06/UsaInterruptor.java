package semana06;

public class UsaInterruptor {

	public static void main(String[] args) {
		Interruptor i = new Interruptor();
		i.acionar();
		i.acionar();

	}

}
